import { Home, Plus, FileText } from 'lucide-react';
import { Button } from './ui/button';

interface BottomNavigationProps {
  activeTab: 'home' | 'create' | 'logs';
  onTabChange: (tab: 'home' | 'create' | 'logs') => void;
}

export function BottomNavigation({ activeTab, onTabChange }: BottomNavigationProps) {
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-md border-t border-slate-200 shadow-lg">
      <div className="flex justify-around items-center py-2 max-w-md mx-auto">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => onTabChange('home')}
          className={`flex flex-col items-center gap-1 h-auto py-3 px-4 rounded-xl transition-all duration-200 ${
            activeTab === 'home' 
              ? 'bg-blue-100 text-blue-600 shadow-sm' 
              : 'text-slate-500 hover:text-slate-700 hover:bg-slate-100'
          }`}
        >
          <Home size={20} />
          <span className="text-xs font-medium">Home</span>
        </Button>
        
        <Button
          variant="ghost"
          size="sm"
          onClick={() => onTabChange('create')}
          className={`flex flex-col items-center gap-1 h-auto py-3 px-4 rounded-xl transition-all duration-200 ${
            activeTab === 'create' 
              ? 'bg-blue-100 text-blue-600 shadow-sm' 
              : 'text-slate-500 hover:text-slate-700 hover:bg-slate-100'
          }`}
        >
          <Plus size={20} />
          <span className="text-xs font-medium">Create</span>
        </Button>
        
        <Button
          variant="ghost"
          size="sm"
          onClick={() => onTabChange('logs')}
          className={`flex flex-col items-center gap-1 h-auto py-3 px-4 rounded-xl transition-all duration-200 ${
            activeTab === 'logs' 
              ? 'bg-blue-100 text-blue-600 shadow-sm' 
              : 'text-slate-500 hover:text-slate-700 hover:bg-slate-100'
          }`}
        >
          <FileText size={20} />
          <span className="text-xs font-medium">Logs</span>
        </Button>
      </div>
    </div>
  );
}